//
//  ScheduleController.swift
//  Final Project
//
//  Created by Sebastian Connelly (student LM) on 12/11/16.
//  Copyright © 2016 Sebastian Connelly (student LM). All rights reserved.
//

import UIKit

class ScheduleController: UIViewController, UITextFieldDelegate{
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        print(textField.text!)
        
        let defaults = UserDefaults.standard
        defaults.set(textField.text!, forKey: "Set \(textField.tag)")
        defaults.synchronize()
        
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func ShowPopUp(_ sender: UIButton) {
        let popOverVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "sbPopUpID") as! PopUpViewController
        self.addChildViewController(popOverVC)
        popOverVC.view.frame = self.view.frame
        self.view.addSubview(popOverVC.view)
        popOverVC.didMove(toParentViewController: self)
        
    }
}
