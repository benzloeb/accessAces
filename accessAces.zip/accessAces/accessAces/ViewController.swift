//
//  ViewController.swift
//  Final Project
//
//  Created by Sebastian Connelly (student LM) on 12/2/16.
//  Copyright © 2016 Sebastian Connelly (student LM). All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func OpenInSafari(_ sender: UIButton) {
        UIApplication.shared.openURL(NSURL(string: "https://www.google.com") as! URL)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}

